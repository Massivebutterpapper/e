export interface WebSocketResponse {
	status: number;
	statusDescription: string;
	message: string;
}