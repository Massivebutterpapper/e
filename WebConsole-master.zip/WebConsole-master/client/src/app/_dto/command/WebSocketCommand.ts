export interface WebSocketCommand {
	command: string;
	params?: string;
	token?: string;
}